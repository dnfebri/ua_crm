

<?php $__env->startSection('contents'); ?>
<!-- Content Header (Page header) -->
<div class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1 class="m-0">Daftar Nama Karyawan</h1>
      </div><!-- /.col -->

    </div><!-- /.row -->
  </div><!-- /.container-fluid -->
</div>
<!-- /.content-header -->



<!-- Main content  ---------------------------------------------------------------------------------------------------------->
<section class="content">
  <div class="container">

    <?php if(session('massage')): ?>
    <div id="massage" data-massage="<?php echo e(session('massage')); ?>"></div>
    <?php endif; ?>

    <div class="row">
      <div class="col">
        <a href="<?php echo e(route('karyawan.create')); ?>" class="btn btn-primary mb-3">Tambah Karyawan</a>

        <table class="table table-striped table-hover">
          <thead>
            <tr>
              <th scope="col">#</th>
              <th scope="col">Nama</th>
              <th scope="col">Club</th>
              <th scope="col">Divisi</th>
              <th scope="col">Jabatan</th>
              <th scope="col">Action</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $karyawan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <th scope="row"><?php echo e($loop->iteration); ?></th>
              <td><?php echo e($k->nama_karyawan); ?></td>
              <td><?php echo e($k->nama_club); ?></td>
              <td><?php echo e($k->nama_divisi); ?></td>
              <td><?php echo e($k->nama_jabatan); ?></td>
              <td>
                <a href="<?php echo e(route('karyawan.show', ['karyawan' => $k->id])); ?>"
                  class="badge bg-black rounded-pill text-decoration-none">Detail</a>
                <a href="#" class="badge bg-green rounded-pill text-decoration-none">Edit</a>
                <a href="#" class="badge bg-red rounded-pill text-decoration-none">Delete</a>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>

      </div>
    </div>

  </div><!-- /.container-fluid -->
</section>
<!-- /.content akhir -------------------------------------------------------------------------------------------------------->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/main', ['title' => 'Daftar Nama Karyawan', 'side' => 'Karyawan'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\dnfebri-github\ua_crm\resources\views/karyawans/index.blade.php ENDPATH**/ ?>