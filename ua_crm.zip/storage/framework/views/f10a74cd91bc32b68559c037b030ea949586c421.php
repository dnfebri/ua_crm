

<?php $__env->startSection('contents'); ?>
<!-- Content Header (Page header) -->
<div class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1 class="m-0">Upload File Karyawan</h1>
      </div>

    </div><!-- /.row -->
  </div><!-- /.container-fluid -->
</div>
<!-- /.content-header -->


<!-- Main content  ---------------------------------------------------------------------------------------------------------->
<section class="content">
  <div class="container">

    
    <div class="row">
      <div class="col-sm-4">

        <div class="card">
          <img src="<?php echo e(url('img/karyawan/foto/default.jpg')); ?>" class="img-fluid img-thumbnail rounded mx-auto d-block"
            alt="..." style="width: 13rem;">
          <div class="card-body">
            <h3 class="font-weight-bold"><?php echo e($data->nama_karyawan); ?></h3>
            <h4 class="font-weight-bold"><?php echo e($data->nik); ?></h4>
            <h5 class="font-weight-normal">Club : <?php echo e($data->nama_club); ?></h5>
            <h5 class="font-weight-normal">Divisi : <?php echo e($data->nama_divisi); ?></h5>
            <h5 class="font-weight-normal">Jabatan : <?php echo e($data->nama_jabatan); ?></h5>
            <p class="card-text"><small class="text-muted">Tanggal Terdaftar :
                <?php echo e(date('d F Y', strtotime($data->tgl_masuk))); ?></small></p>
            <p>
              Status Karyawan :
              <?php if($data->status_karyawan != '0'): ?>
              <span class="text-green font-weight-bold">
                <?php echo e($data->status_karyawan); ?>

              </span>
              <?php else: ?>
              <span class="text-red font-weight-bold">
                NON AKTIV
              </span>
              <?php endif; ?>
            </p>
          </div>
        </div>
      </div>

      <div class="col-sm-8">
        <div class="card card-secondary">
          <div class="card-header">
            <h3 class="card-title font-weight-bold">Upload File</h3>

            <div class="card-tools">
              <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                <i class="fas fa-minus"></i>
              </button>
              
            </div>
          </div>
          <div class="card-body">
            <form action="<?php echo e(route('filekaryawan.store')); ?>" method="post" enctype="multipart/form-data">
              <?php echo csrf_field(); ?>
              <input type="text" name="id_karyawan" id="id_karyawan" value="<?php echo e($data->id); ?>" hidden>
              <div class="mb-3 row">
                <label for="img_foto" class="col-lg-3 col-form-label">Foto Karyawan</label>
                <div class="col-lg-9">
                  <div class="mb-3">
                    <input class="form-control mb-2 input-img <?php $__errorArgs = ['img_foto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="img_foto"
                      name="img_foto" value="" type="file">
                    <?php $__errorArgs = ['img_foto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div id="img_foto" class="invalid-feedback">
                      <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <img src="<?php echo e(url('img/karyawan/default.png')); ?>" class="img-thumbnail img-previuw">
                    <div class="img-label">

                    </div>
                  </div>
                </div>
              </div>

              <div class="mb-3 row">
                <label for="img_ktp" class="col-lg-3 col-form-label">Foto KTP</label>
                <div class="col-lg-9">
                  <div class="mb-3">
                    <input class="form-control mb-2 input-img <?php $__errorArgs = ['img_ktp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="img_ktp"
                      name="img_ktp" value="" type="file">
                    <?php $__errorArgs = ['img_ktp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div id="img_ktp" class="invalid-feedback">
                      <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <img src="<?php echo e(url('img/karyawan/default.png')); ?>" class="img-thumbnail img-previuw">
                    <div class="img-label">

                    </div>
                  </div>
                </div>
              </div>

              <div class="mb-3 row">
                <label for="img_kartu_keluarga" class="col-lg-3 col-form-label">Foto Kartu Keluarga</label>
                <div class="col-lg-9">
                  <div class="mb-3">
                    <input class="form-control mb-2 input-img <?php $__errorArgs = ['img_kartu_keluarga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                      id="img_kartu_keluarga" name="img_kartu_keluarga" value="" type="file">
                    <?php $__errorArgs = ['img_kartu_keluarga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div id="img_kartu_keluarga" class="invalid-feedback">
                      <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <img src="<?php echo e(url('img/karyawan/default.png')); ?>" class="img-thumbnail img-previuw">
                    <div class="img-label">

                    </div>
                  </div>
                </div>
              </div>

              <div class="mb-3 row">
                <label for="img_ijazah" class="col-lg-3 col-form-label">Foto Ijazah</label>
                <div class="col-lg-9">
                  <div class="mb-3">
                    <input class="form-control mb-2 input-img <?php $__errorArgs = ['img_ijazah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="img_ijazah"
                      name="img_ijazah" value="" type="file">
                    <?php $__errorArgs = ['img_ijazah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div id="img_ijazah" class="invalid-feedback">
                      <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <img src="<?php echo e(url('img/karyawan/default.png')); ?>" class="img-thumbnail img-previuw">
                    <div class="img-label">

                    </div>
                  </div>
                </div>
              </div>

              <div class="mb-3 row">
                <label for="img_rek_mandiri" class="col-lg-3 col-form-label">Foto Rekening Mandiri</label>
                <div class="col-lg-9">
                  <div class="mb-3">
                    <input class="form-control mb-2 input-img <?php $__errorArgs = ['img_rek_mandiri'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                      id="img_rek_mandiri" name="img_rek_mandiri" value="" type="file">
                    <?php $__errorArgs = ['img_rek_mandiri'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div id="img_rek_mandiri" class="invalid-feedback">
                      <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <img src="<?php echo e(url('img/karyawan/default.png')); ?>" class="img-thumbnail img-previuw">
                    <div class="img-label">

                    </div>
                  </div>
                </div>
              </div>

              <div class="d-grid gap-2 col-6 mx-auto">
                
                <button class="btn btn-success" type="submit"><i class="fas fa-save me-md-1"></i> Simpan</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
    



  </div>

  </div><!-- /.container-fluid -->
</section>
<!-- /.content akhir -------------------------------------------------------------------------------------------------------->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/main', ['title' => 'Upload File Karyawan', 'side' => 'Karyawan'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\dnfebri-github\ua_crm\resources\views/filekaryawan/create.blade.php ENDPATH**/ ?>