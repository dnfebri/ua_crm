<script>
  $(function () {
  //Initialize Select2 Elements
  $('.select2').select2()

  //Initialize Select2 Elements
  $('.select2bs4').select2({
    theme: 'bootstrap4'
  })

  //Datemask dd/mm/yyyy
  $('#datemask').inputmask('dd/mm/yyyy', { 'placeholder': 'dd/mm/yyyy' })
  //Datemask2 mm/dd/yyyy
  $('#datemask2').inputmask('mm/dd/yyyy', { 'placeholder': 'mm/dd/yyyy' })
  //Money Euro
  $('[data-mask]').inputmask()

  //Date picker
  $('#reservationdate_1').datetimepicker({
      format: 'YYYY-M-D'
  });
  $('#reservationdate_2').datetimepicker({
      format: 'YYYY-M-D'
      // format: 'L'
  });

})
</script>



<?php /**PATH D:\xampp\htdocs\dnfebri-github\ua_crm\resources\views/layouts/script_datepicker.blade.php ENDPATH**/ ?>