<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?php echo e($title ?? config('app.name')); ?></title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet"
    href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo e(url('dist/fontawesome-free/css/all.min.css')); ?>">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">

  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo e(url('dist/css/adminlte.min.css')); ?>">


  
  
  <link rel="stylesheet"
    href="<?php echo e(url('dist/plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css')); ?>">
  
  


  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="<?php echo e(url('dist/css/bootstrap.min.css')); ?>">
  

  
  <script src="<?php echo e(url('dist/sweetalert/sweetalert2.min.js')); ?>"></script>
  <link rel="stylesheet" href="<?php echo e(url('dist/sweetalert/sweetalert2.min.css')); ?>">

  <!-- My Style CSS -->
  <link rel="stylesheet" href="<?php echo e(url('css/style.css')); ?>">

</head>

<body class="hold-transition sidebar-mini layout-fixed">
  <div class="wrapper">

    <!-- Navbar -->
    <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- /.navbar -->

    <!-- Sidebar -->
    <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- /.Sidebar -->

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">

      <?php echo $__env->yieldContent('contents'); ?>

    </div>
    <!-- /.content-wrapper -->
    <footer class="main-footer">
      <strong>Copyright &copy; 2021 <a href="#">Urban Athletes</a>.</strong>
      All rights reserved.
      <!-- <div class="float-right d-none d-sm-inline-block">
        <b>Version</b> 3.1.0
      </div> -->
    </footer>

    <!-- Control Sidebar -->
    <aside class="control-sidebar control-sidebar-dark">
      <!-- Control sidebar content goes here -->
    </aside>
    <!-- /.control-sidebar -->
  </div>
  <!-- ./wrapper -->

  <!-- jQuery -->
  <script src="<?php echo e(url('dist/jquery/jquery.min.js')); ?>"></script>
  <!-- Bootstrap 4 -->
  <script src="<?php echo e(url('dist/js/bootstrap.min.js')); ?>"></script>
  <script src="<?php echo e(url('dist/js/bootstrap.bundle.min.js')); ?>"></script>
  <!-- Option 1: Bootstrap Bundle with Popper -->
  



  <!-- AdminLTE App -->
  <script src="<?php echo e(url('dist/js/adminlte.js')); ?>"></script>
  <!-- AdminLTE for demo purposes -->
  <script src="<?php echo e(url('dist/js/demo.js')); ?>"></script>

  <script src="<?php echo e(url('dist/plugins/select2/js/select2.full.min.js')); ?>"></script>
  
  <script src="<?php echo e(url('dist/plugins/moment/moment.min.js')); ?>"></script>
  <script src="<?php echo e(url('dist/plugins/inputmask/jquery.inputmask.min.js')); ?>"></script>
  
  
  <script src="<?php echo e(url('dist/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js')); ?>"></script>
  
  
  

  
  <script src="<?php echo e(url('js/massage.js')); ?>"></script>
  <script src="<?php echo e(url('js/script.js')); ?>"></script>

  <!-- Script Datepicker -->
  <?php if(!empty($datepicker)): ?>
  <?php echo $__env->make('layouts.script_datepicker', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php endif; ?>
  <!-- /.vScript Datepicker -->

</body>

</html><?php /**PATH D:\xampp\htdocs\dnfebri-github\ua_crm\resources\views/layouts/main.blade.php ENDPATH**/ ?>