

<?php $__env->startSection('contents'); ?>
<!-- Content Header (Page header) -->
<div class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1 class="m-0">Tambah Nama Karyawan</h1>
      </div><!-- /.col -->

    </div><!-- /.row -->
  </div><!-- /.container-fluid -->
</div>
<!-- /.content-header -->




<!-- Main content  ---------------------------------------------------------------------------------------------------------->
<section class="content">
  <div class="container mb-3">
    <!-- Small boxes (Stat box) -->
    <div class="row">
      <div class="col-sm-12">
        <form action="<?php echo e(route('karyawan.store')); ?>" method="post">
          <?php echo csrf_field(); ?>
          <div class="mb-2 row">
            <label for="nik" class="col-sm-2 col-form-label">NIK</label>
            <div class="col-sm-10">
              <input type="text" class="form-control <?php $__errorArgs = ['nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nik" name="nik"
                value="<?php echo e(old('nik')); ?>" placeholder="NIK">
              <?php $__errorArgs = ['nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div id="nik" class="invalid-feedback">
                <?php echo e($message); ?>

              </div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
          <div class="mb-2 row">
            <label for="nama_karyawan" class="col-sm-2 col-form-label">Nama Karyawan</label>
            <div class="col-sm-10">
              <input type="text" class="form-control <?php $__errorArgs = ['nama_karyawan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nama_karyawan"
                name="nama_karyawan" value="<?php echo e(old('nama_karyawan')); ?>" placeholder="Nama Karyawan">
              <?php $__errorArgs = ['nama_karyawan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div id="nama_karyawan" class="invalid-feedback">
                <?php echo e($message); ?>

              </div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
          <div class="mb-2 row">
            <label for="club" class="col-sm-2 col-form-label">Club</label>
            <div class="col-sm-10">
              <select class="form-select <?php $__errorArgs = ['club'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="club" id="club">
                <option value="" selected>Pilih Club</option>
                <?php $__currentLoopData = $clubs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $club): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($club->id); ?>" <?php echo e(old('club') == $club->id ? 'selected' : ''); ?>><?php echo e($club->nama_club); ?>

                </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
              <?php $__errorArgs = ['club'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div id="club" class="invalid-feedback">
                <?php echo e($message); ?>

              </div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
          <div class="mb-2 row">
            <label for="divisi" class="col-sm-2 col-form-label">Divisi</label>
            <div class="col-sm-10">
              <select class="form-select <?php $__errorArgs = ['divisi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="divisi" id="divisi">
                <option value="" selected>Pilih Divisi</option>
                <?php $__currentLoopData = $divisis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $divisi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($divisi->id); ?>" <?php echo e(old('divisi') == $divisi->id ? 'selected' : ''); ?>>
                  <?php echo e($divisi->nama_divisi); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
              <?php $__errorArgs = ['divisi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div id="divisi" class="invalid-feedback">
                <?php echo e($message); ?>

              </div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
          <div class="mb-2 row">
            <label for="jabatan" class="col-sm-2 col-form-label">Jabatan</label>
            <div class="col-sm-10">
              <select class="form-select <?php $__errorArgs = ['jabatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="jabatan" id="jabatan">
                <option value="" selected>Pilih Jabatan</option>
                <?php $__currentLoopData = $jabatans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jabatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($jabatan->id); ?>" <?php echo e(old('jabatan') == $jabatan->id ? 'selected' : ''); ?>>
                  <?php echo e($jabatan->nama_jabatan); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
              <?php $__errorArgs = ['jabatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div id="jabatan" class="invalid-feedback">
                <?php echo e($message); ?>

              </div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
          <div class="mb-2 row">
            <label for="jenis_kelamin" class="col-sm-2 col-form-label">Jenis Kelamin</label>
            <div class="col-sm-10">
              <select class="form-select <?php $__errorArgs = ['jenis_kelamin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="jenis_kelamin"
                id="jenis_kelamin">
                <option value="" selected>Pilih Jenis Kelamin</option>
                <option value="Laki-Laki" <?php echo e(old('jenis_kelamin') == "Laki-Laki" ? 'selected' : ''); ?>>Laki-Laki</option>
                <option value="Perempuan" <?php echo e(old('jenis_kelamin') == "Perempuan" ? 'selected' : ''); ?>>Perempuan</option>
              </select>
              <?php $__errorArgs = ['jenis_kelamin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div id="jenis_kelamin" class="invalid-feedback">
                <?php echo e($message); ?>

              </div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
          <div class="mb-2 row">
            <label for="no_ktp" class="col-sm-2 col-form-label">No KTP</label>
            <div class="col-sm-10">
              <input type="text" class="form-control <?php $__errorArgs = ['no_ktp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="no_ktp" name="no_ktp"
                value="<?php echo e(old('no_ktp')); ?>" placeholder="No KTP">
              <?php $__errorArgs = ['no_ktp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div id="no_ktp" class="invalid-feedback">
                <?php echo e($message); ?>

              </div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
          <div class="mb-2 row">
            <label for="alamat_ktp" class="col-sm-2 col-form-label">Alamat KTP</label>
            <div class="col-sm-10">
              <input type="text" class="form-control <?php $__errorArgs = ['alamat_ktp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="alamat_ktp"
                name="alamat_ktp" value="<?php echo e(old('alamat_ktp')); ?>" placeholder="Alamat KTP">
              <?php $__errorArgs = ['alamat_ktp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div id="alamat_ktp" class="invalid-feedback">
                <?php echo e($message); ?>

              </div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
          <div class="mb-2 row">
            <label for="alamat_tmpt_tinggal" class="col-sm-2 col-form-label"></label>
            <div class="col-sm-10">
              <div class="icheck-primary">
                <input type="checkbox" name="checkbox_ktp" id="checkbox_ktp" <?php echo e(old('checkbox_ktp') ? 'checked' : ''); ?>>
                <label for="checkbox_ktp">Alamat Tempat Tinggal Sesuai KTP</label>
              </div>
            </div>
          </div>
          <div class="mb-2 row">
            <label for="alamat_tmpt_tinggal" class="col-sm-2 col-form-label">Alamat Tempat Tinggal</label>
            <div class="col-sm-10">
              <input type="text" class="form-control <?php $__errorArgs = ['alamat_tmpt_tinggal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                id="alamat_tmpt_tinggal" name="alamat_tmpt_tinggal" value="<?php echo e(old('alamat_tmpt_tinggal')); ?>"
                placeholder="Alamat Tempat Tinggal">
              <?php $__errorArgs = ['alamat_tmpt_tinggal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div id="alamat_tmpt_tinggal" class="invalid-feedback">
                <?php echo e($message); ?>

              </div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
          <div class="mb-2 row">
            <label for="email" class="col-sm-2 col-form-label">Email</label>
            <div class="col-sm-10">
              <input type="text" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email" name="email"
                value="<?php echo e(old('email')); ?>" placeholder="Email">
              <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div id="email" class="invalid-feedback">
                <?php echo e($message); ?>

              </div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
          <div class="mb-2 row">
            <label for="tempat_lahir" class="col-sm-2 col-form-label">Tempat lahir</label>
            <div class="col-sm-10">
              <input type="text" class="form-control <?php $__errorArgs = ['tempat_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="tempat_lahir"
                name="tempat_lahir" value="<?php echo e(old('tempat_lahir')); ?>" placeholder="Tempat lahir">
              <?php $__errorArgs = ['tempat_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div id="tempat_lahir" class="invalid-feedback">
                <?php echo e($message); ?>

              </div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
          <div class="mb-2 row">
            <label for="tanggal_lahir" class="col-sm-2 col-form-label">Tanggal lahir</label>
            <div class="col-sm-10">

              <div class="input-group date" id="reservationdate_1" data-target-input="nearest">
                <div class="input-group-append" data-target="#reservationdate_1" data-toggle="datetimepicker">
                  <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                </div>
                <input type="text"
                  class="form-control datetimepicker-input <?php $__errorArgs = ['tanggal_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                  id="tanggal_lahir" name="tanggal_lahir" data-target="#reservationdate_1" data-toggle="datetimepicker"
                  value="<?php echo e(old('tanggal_lahir')); ?>" placeholder="Tanggal lahir" />
                <?php $__errorArgs = ['tanggal_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div id="tanggal_lahir" class="invalid-feedback">
                  <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
              
            </div>
          </div>
          <div class="mb-2 row">
            <label for="no_telpon" class="col-sm-2 col-form-label">Nomer Telpon</label>
            <div class="col-sm-10">
              <input type="text" class="form-control <?php $__errorArgs = ['no_telpon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="no_telpon"
                name="no_telpon" value="<?php echo e(old('no_telpon')); ?>" placeholder="Nomer Telpon">
              <?php $__errorArgs = ['no_telpon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div id="no_telpon" class="invalid-feedback">
                <?php echo e($message); ?>

              </div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
          <div class="mb-2 row">
            <label for="nama_ibu_kandung" class="col-sm-2 col-form-label">Nama Ibu Kandung</label>
            <div class="col-sm-10">
              <input type="text" class="form-control <?php $__errorArgs = ['nama_ibu_kandung'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                id="nama_ibu_kandung" name="nama_ibu_kandung" value="<?php echo e(old('nama_ibu_kandung')); ?>"
                placeholder="Nama Ibu Kandung">
              <?php $__errorArgs = ['nama_ibu_kandung'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div id="nama_ibu_kandung" class="invalid-feedback">
                <?php echo e($message); ?>

              </div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
          <div class="mb-2 row">
            <label for="gol_darah" class="col-sm-2 col-form-label">Gol Darah</label>
            <div class="col-sm-10">
              <select class="form-select <?php $__errorArgs = ['gol_darah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="gol_darah" id="gol_darah">
                <option value="" selected>Pilih Gol Darah</option>
                <option value="A" <?php echo e(old('gol_darah') == "A" ? 'selected' : ''); ?>>A</option>
                <option value="B" <?php echo e(old('gol_darah') == "B" ? 'selected' : ''); ?>>B</option>
                <option value="AB" <?php echo e(old('gol_darah') == "AB" ? 'selected' : ''); ?>>AB</option>
                <option value="O" <?php echo e(old('gol_darah') == "O" ? 'selected' : ''); ?>>O</option>
              </select>
              <?php $__errorArgs = ['gol_darah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div id="gol_darah" class="invalid-feedback">
                <?php echo e($message); ?>

              </div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
          <div class="mb-2 row">
            <label for="agama" class="col-sm-2 col-form-label">Agama</label>
            <div class="col-sm-10">
              <select class="form-select <?php $__errorArgs = ['agama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="agama" id="agama">
                <option value="" selected>Pilih Agama</option>
                <option value="ISLAM" <?php echo e(old('agama') == "ISLAM" ? 'selected' : ''); ?>>ISLAM</option>
                <option value="KATOLIK" <?php echo e(old('agama') == "KATOLIK" ? 'selected' : ''); ?>>KATOLIK</option>
                <option value="HINDU" <?php echo e(old('agama') == "HINDU" ? 'selected' : ''); ?>>HINDU</option>
                <option value="BUDDHA" <?php echo e(old('agama') == "BUDDHA" ? 'selected' : ''); ?>>BUDDHA</option>
                <option value="PROTESTAN" <?php echo e(old('agama') == "PROTESTAN" ? 'selected' : ''); ?>>PROTESTAN</option>
              </select>
              <?php $__errorArgs = ['agama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div id="agama" class="invalid-feedback">
                <?php echo e($message); ?>

              </div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
          <div class="mb-2 row">
            <label for="status_pernikahan" class="col-sm-2 col-form-label">Status Pernikahan</label>
            <div class="col-sm-10">
              <select class="form-select <?php $__errorArgs = ['status_pernikahan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="status_pernikahan"
                id="status_pernikahan">
                <option value="" selected>Pilih Status Pernikahan</option>
                <option value="Belum Menikah" <?php echo e(old('status_pernikahan') == "Belum Menikah" ? 'selected' : ''); ?>>Belum
                  Menikah</option>
                <option value="Menikah" <?php echo e(old('status_pernikahan') == "Menikah" ? 'selected' : ''); ?>>Menikah</option>
                <option value="Cerai Hidup" <?php echo e(old('status_pernikahan') == "Cerai Hidup" ? 'selected' : ''); ?>>Cerai Hidup
                </option>
                <option value="Cerai Mati" <?php echo e(old('status_pernikahan') == "Cerai Mati" ? 'selected' : ''); ?>>Cerai Mati
                </option>
              </select>
              <?php $__errorArgs = ['status_pernikahan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div id="status_pernikahan" class="invalid-feedback">
                <?php echo e($message); ?>

              </div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
          <div class="mb-2 row">
            <label for="tanggungan_anak" class="col-sm-2 col-form-label">Tanggungan Anak</label>
            <div class="col-sm-10">
              <select class="form-select <?php $__errorArgs = ['tanggungan_anak'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="tanggungan_anak"
                id="tanggungan_anak">
                <option value="" selected>Pilih Tanggungan Anak</option>
                <option value="0" <?php echo e(old('tanggungan_anak') == "0" ? 'selected' : ''); ?>>0</option>
                <option value="1" <?php echo e(old('tanggungan_anak') == "1" ? 'selected' : ''); ?>>1</option>
                <option value="2" <?php echo e(old('tanggungan_anak') == "2" ? 'selected' : ''); ?>>2</option>
                <option value="3" <?php echo e(old('tanggungan_anak') == "3" ? 'selected' : ''); ?>>3</option>
                <option value="4" <?php echo e(old('tanggungan_anak') == "4" ? 'selected' : ''); ?>>4</option>
                <option value="5" <?php echo e(old('tanggungan_anak') == "5" ? 'selected' : ''); ?>>5</option>
              </select>
              <?php $__errorArgs = ['tanggungan_anak'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div id="tanggungan_anak" class="invalid-feedback">
                <?php echo e($message); ?>

              </div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
          <div class="mb-2 row">
            <label for="no_rek_mandiri" class="col-sm-2 col-form-label">Nomer Rekening Mandiri</label>
            <div class="col-sm-10">
              <input type="text" class="form-control <?php $__errorArgs = ['no_rek_mandiri'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="no_rek_mandiri"
                name="no_rek_mandiri" value="<?php echo e(old('no_rek_mandiri')); ?>" placeholder="Nomer Rekening Mandiri">
              <?php $__errorArgs = ['no_rek_mandiri'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div id="no_rek_mandiri" class="invalid-feedback">
                <?php echo e($message); ?>

              </div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
          <div class="mb-2 row">
            <label for="no_npwp" class="col-sm-2 col-form-label">Nomer NPWP</label>
            <div class="col-sm-10">
              <input type="text" class="form-control <?php $__errorArgs = ['no_npwp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="no_npwp" name="no_npwp"
                value="<?php echo e(old('no_npwp')); ?>" placeholder="Nomer NPWP">
              <?php $__errorArgs = ['no_npwp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div id="no_npwp" class="invalid-feedback">
                <?php echo e($message); ?>

              </div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
          <div class="mb-2 row">
            <label for="no_bpjs_kesehatan" class="col-sm-2 col-form-label">Nomer BPJS Kesehatan</label>
            <div class="col-sm-10">
              <input type="text" class="form-control <?php $__errorArgs = ['no_bpjs_kesehatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                id="no_bpjs_kesehatan" name="no_bpjs_kesehatan" value="<?php echo e(old('no_bpjs_kesehatan')); ?>"
                placeholder="Nomer BPJS Kesehatan">
              <?php $__errorArgs = ['no_bpjs_kesehatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div id="no_bpjs_kesehatan" class="invalid-feedback">
                <?php echo e($message); ?>

              </div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
          <div class="mb-2 row">
            <label for="no_bpjs_kt" class="col-sm-2 col-form-label">Nomer BPJS Ketenagakerjaan</label>
            <div class="col-sm-10">
              <input type="text" class="form-control <?php $__errorArgs = ['no_bpjs_kt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="no_bpjs_kt"
                name="no_bpjs_kt" value="<?php echo e(old('no_bpjs_kt')); ?>" placeholder="Nomer BPJS Ketenagakerjaan">
              <?php $__errorArgs = ['no_bpjs_kt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div id="no_bpjs_kt" class="invalid-feedback">
                <?php echo e($message); ?>

              </div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
          <div class="mb-2 row">
            <label for="no_telpon_darurat" class="col-sm-2 col-form-label">Nomer Telpon Darurat</label>
            <div class="col-sm-10">
              <input type="text" class="form-control <?php $__errorArgs = ['no_telpon_darurat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                id="no_telpon_darurat" name="no_telpon_darurat" value="<?php echo e(old('no_telpon_darurat')); ?>"
                placeholder="Nomer Telpon Darurat">
              <?php $__errorArgs = ['no_telpon_darurat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div id="no_telpon_darurat" class="invalid-feedback">
                <?php echo e($message); ?>

              </div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
          <div class="mb-2 row">
            <label for="tgl_masuk" class="col-sm-2 col-form-label">Tanggal Masuk</label>
            <div class="col-sm-10">
              <div class="input-group date" id="reservationdate_2" data-target-input="nearest">
                <div class="input-group-append" data-target="#reservationdate_2" data-toggle="datetimepicker">
                  <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                </div>
                <input type="text" class="form-control datetimepicker-input <?php $__errorArgs = ['tgl_masuk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                  data-target="#reservationdate_2" data-toggle="datetimepicker" id="tgl_masuk" name="tgl_masuk"
                  value="<?php echo e(old('tgl_masuk')); ?>" placeholder="Tanggal Masuk" />
                <?php $__errorArgs = ['tgl_masuk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div id="tgl_masuk" class="invalid-feedback">
                  <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
              
            </div>
          </div>
          
          <div class="mb-2 row">
            <label for="checkbox_ktp" class="col-sm-2 col-form-label"></label>
            <div class="col-sm-10">
              <div class="icheck-primary">
                <input type="checkbox" name="status_karyawan" id="status_karyawan" value="AKTIF"
                  <?php echo e(old('status_karyawan') ? 'checked' : ''); ?>>
                <label for="status_karyawan">Status Karywan Aktif!</label>
              </div>
            </div>
          </div>

          <button type="submit" class="btn btn-success mt-3">Simpan</button>
        </form>
      </div>
    </div>

  </div><!-- /.container-fluid -->
</section>
<!-- /.content akhir -------------------------------------------------------------------------------------------------------->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/main', ['title' => 'Tambah Nama Karyawan', 'side' => 'Karyawan', 'datepicker' => TRUE], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\dnfebri-github\ua_crm\resources\views/karyawans/create.blade.php ENDPATH**/ ?>