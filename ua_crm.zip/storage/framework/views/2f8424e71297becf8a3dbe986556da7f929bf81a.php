

<?php $__env->startSection('contents'); ?>
<!-- Content Header (Page header) -->
<div class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1 class="m-0">Daftar Nama Club</h1>
      </div><!-- /.col -->

    </div><!-- /.row -->
  </div><!-- /.container-fluid -->
</div>
<!-- /.content-header -->



<!-- Main content  ---------------------------------------------------------------------------------------------------------->
<section class="content">
  <div class="container">

    <?php if(session('massage')): ?>
    <div id="massage" data-massage="<?php echo e(session('massage')); ?>"></div>
    <?php endif; ?>

    

    <!-- Small boxes (Stat box) -->
    <div class="row">
      <div class="col-sm-5">
        <a href="<?php echo e(route('club.create')); ?>" class="btn btn-primary mb-3">Tambah Club</a>

        <ol class="list-group list-group-numbered">
          <?php $__currentLoopData = $clubs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $club): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li class="list-group-item d-flex justify-content-between align-items-start">
            <div class="ms-2 me-auto">
              <div class="fw-bold"><?php echo e($club->nama_club); ?></div>
            </div>
            <div>
              
              <a href="<?php echo e(route('club.show', ['club' => $club->id])); ?>"
                class="badge bg-black rounded-pill text-decoration-none">Detail</a>
              
              <form action="<?php echo e(route('club.delete', ['club' => $club->id])); ?>" method="post"
                class="d-inline text-decoration-none">
                <?php echo method_field('delete'); ?>
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn badge bg-danger rounded-pill text-decoration-none"
                  onclick="archiveFunction()">Hapus</button>
              </form>
            </div>
          </li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ol>
      </div>
    </div>

  </div><!-- /.container-fluid -->
</section>
<!-- /.content akhir -------------------------------------------------------------------------------------------------------->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/main', ['title' => 'Daftar Nama Club', 'side' => 'Club'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\dnfebri-github\ua_crm\resources\views/clubs/index.blade.php ENDPATH**/ ?>