<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?php echo e($title ?? config('app.name')); ?></title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet"
    href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo e(url('dist/fontawesome-free/css/all.min.css')); ?>">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">

  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo e(url('dist/css/adminlte.min.css')); ?>">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="<?php echo e(url('dist/css/bootstrap.min.css')); ?>">
  

  
  <script src="<?php echo e(url('dist/sweetalert/sweetalert2.min.js')); ?>"></script>
  <link rel="stylesheet" href="<?php echo e(url('dist/sweetalert/sweetalert2.min.css')); ?>">


</head>

<body class="hold-transition login-page">

  <?php echo $__env->yieldContent('auth'); ?>

  <!-- jQuery -->
  <script src="<?php echo e(url('dist/jquery/jquery.min.js')); ?>"></script>
  <!-- Bootstrap 4 -->
  <script src="<?php echo e(url('dist/js/bootstrap.min.js')); ?>"></script>
  <script src="<?php echo e(url('dist/js/bootstrap.bundle.min.js')); ?>"></script>
  <!-- Option 1: Bootstrap Bundle with Popper -->
  



  <!-- AdminLTE App -->
  <script src="<?php echo e(url('dist/js/adminlte.js')); ?>"></script>
  <!-- AdminLTE for demo purposes -->
  <script src="<?php echo e(url('dist/js/demo.js')); ?>"></script>

  
  <script src="<?php echo e(url('js/massage.js')); ?>"></script>
  <script src="<?php echo e(url('js/script.js')); ?>"></script>
</body>

</html><?php /**PATH D:\xampp\htdocs\dnfebri-github\ua_crm\resources\views/layouts/main-auth.blade.php ENDPATH**/ ?>